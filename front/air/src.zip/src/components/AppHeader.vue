<template>
  <header class="px-4 py-3 flex justify-between items-center border-b">
    <h1 class="text-lg font-semibold text-black text-center w-full">2025년 6월 27일 금요일</h1>
    <button class="text-gray-600">
      <span class="material-icons">calendar_today</span>
    </button>
  </header>
</template>

<script setup>
defineProps({
  date: String,
})
</script>
